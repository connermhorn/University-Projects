# Step Counter Project 
## ENCE361: Embedded Systems 1 

 

### Authors: Conner Horn & Cade Hinman 

### Student ID: 36757479 & 27567040 

 

### Date: 26 May 2025 
--- 
## 1. Description of the Overall Project 
This report presents the outcome of an embedded system designed to count steps, known as a Step Counter or Pedometer. The project was implemented using an STM32C071 Microcontroller and an RCAP development board. It builds on weekly lab work during Term 1, focusing on:

- **Interfacing with peripherals:** GPIO, user switches, ADC, timers, and PWM.
- **Task scheduling:** Round-robin and interrupt-based scheduling.
- **Data processing:** Buffering, latency analysis, and filtering.
- **Algorithm development:** Step detection and distance estimation.
- **System design:** Meeting functional specifications.
- **System testing:** Modularization, debugging, and optimization.


#### How to Use the Step Counter
**Powering On:**

Remove the jumper from the main board and fit a battery pack to the board.
Switch the power source from **ST-LINK** to **BAT**.
Press the **On Button** on the battery pack.

**Startup Indication:**

A beep will be played by the buzzer to indicate that the device is powered on.

**Step Counting:**

Begin walking or running. The step counter will automatically increment with each step.

**Viewing Statistics:**

Push the joystick **left** or **right** to cycle through different statistics:
- **Current Steps**
- **Progress Towards Goal**
- **Distance Travelled**

**Changing Units:**

Push the joystick **up** or **down** to toggle between different units (e.g., steps as a percentage of the goal or distance in kilometers/yards).


**Test Mode:**

Double-tap **SW**2 rapidly to enter **Test Mode**. The display will indicate "Test Mode" at the top.
Use the joystick to simulate steps:
Push **up** to increment steps (rate proportional to joystick displacement).
Push **down** to decrement steps.
Double-tap **SW2** again to exit Test Mode.


**Setting a Goal:**

Press and hold the joystick **down** for more than 1 second to enter the goal-setting mode.
Use the rotary dial (potentiometer) to set a goal between **500 steps** and **15,000 steps**.
Confirm the goal by holding the joystick **down** for more than 1 second.
To revert to the previous goal, click the joystick **down** once.


**Goal Completion:**

Upon reaching the desired goal, the buzzer will play the same tone as when the device was powered on.

--- 

## 2. Justification and Description of Modularisation 

The structure of the program was designed with future-proofing and maintenance in mind. To keep the code manageable, scalable, and testable, the project was split into logical modules based on functionality. This modular structure enabled: 

* **Independent Development:** Tasks such as display, buzzer, button, step, blinky, joystick, and IMU were developed independently.
* **Ease of Debugging:** Each task was isolated, making debugging straightforward. For example, debugging the joystick was separate from the display or step tasks.
* **Feature Implementation:** Modular design allowed new features to be added with minimal risk of breaking existing functionality.
* **Scheduling and Timing:** Using a time-triggered scheduler (app.c loop) ensured deterministic task execution based on system ticks (HAL_GetTick()), reducing overhead and ensuring smooth operation. 

Modularisation has helped throughout the project to avoid tight coupling between hardware setup and software. Each task has been further modularized into source `.c` and header `.h` file pairs.  

Below is a dependency graph (Figure 1) that visualizes the modularization used in the project: 

### Firmware File Dependency Diagram

```text
                 +----------------+
                 |    main.c      |
                 | (uses app.h)   |
                 +-------+--------+
                         |
                         v
                 +----------------+
                 |     app.c      |
                 | (orchestrator) |
                 +--+---+---+--+--+
                    |   |      |
                    |   |      |
     ---------------+   |      +-------------------------------+
     |                  |              |                       |
     v                  v              v                       v
+-----------+   +------------+   +-----------+        +------------------+
| globals.c |   |  filter.c  |   |  peak.c   |        | task_blinky.c    |
| (enum)    |   |            |   | (HAL)     |        | (gpio.h)         |
+-----+-----+   +------------+   +-----------+        +------------------+
      |                                                   
      v                                                   
+------------------+                                       
| task_display.c   |<------------------+                  
| (ssd1306, etc.)  |                   |                  
+--------+---------+                   |                  
         ^                             |                  
         |                             |                  
+------------------+        +--------------------+        
| task_button.c    |<------>|   task_steps.c     |<-----+
| (display, steps) |        | (buzzer, display)  |      |
+------------------+        +--------------------+      |
         ^                                             |
         |                                             |
+------------------+         +-------------------+     |
| task_buzzer.c    |<--------| task_joystick.c   |<----+
| (joystick, disp) |         | (steps, HW)       |
+------------------+         +-------------------+
                                         |
                                         v
                                +------------------+
                                |   task_imu.c     |
                                |   (LSM6DS)       |
                                +------------------+

Legend:
- All tasks also include app.h and globals.h (omitted for clarity).
- Arrows indicate dependency or data flow.
- Double arrows (<-->) indicate mutual interaction.
```
An example of modularity is present in `task_button.c`. When the UP (SW1) button is pressed, the button task increments the step count and calls the step module to check if the goal has been reached, and then if the buzzer should be activated:
``` 
if (buttons_checkButton(UP) == PUSHED) 

{ 

    // Increment step counter by 80 steps per press 

    stepCount += 80; 

    steps_check_goal_and_buzzer(); // Check goal status when SW1 is pushed 

} 

``` 

This was the best way we found to make our program modular, it made each module clear on what it needed to do, whilst keeping the functionality of the program the same.   

--- 

## 3. Analysis of Firmware Operation

### Sensor Data Acquisition and Processing

This section details the approach to acquiring and processing raw sensor data from the integrated modules, including Analog-to-Digital Converter (ADC) values from the joystick and raw motion data from the Inertial Measurement Unit (IMU). It provides example data to illustrate the typical outputs and their subsequent interpretation and filtering.

---

### Joystick Module (`task_joystick.c` and `task_display.c`)

The joystick serves as a primary user input mechanism, providing proportional control through its X and Y axes, along with a potentiometer (VR1) for additional input. The system utilizes a 12-bit ADC to convert the analog voltage signals from the joystick into digital values, resulting in a raw data range from 0 to 4095. These raw values are then processed for navigation across display screens, toggling units, and adjusting goal settings.

#### Raw ADC Data Examples

| Joystick Position | adc_x (Raw) | adc_y (Raw) | adc_vr1 (Raw) | Displayed X (Direction & %) | Displayed Y (Direction & %) | Goal Setting Context (VR1)          |
|-------------------|-------------|-------------|---------------|-----------------------------|-----------------------------|------------------------------------|
| Center (Rest)     | 2048        | 2048        | 2000          | X: Rest 0%                  | Y: Rest 0%                  | ~7500 steps (mid-range)             |
| Moved Right       | 1500        | 2048        | 2000          | X: Right 38%                | Y: Rest 0%                  | ~7500 steps                        |
| Moved Left        | 2500        | 2048        | 2000          | X: Left 38%                 | Y: Rest 0%                  | ~7500 steps                        |
| Moved Up          | 2048        | 1500        | 2000          | X: Rest 0%                  | Y: Up 38%                   | ~7500 steps                        |
| Moved Down        | 2048        | 2500        | 2000          | X: Rest 0%                  | Y: Down 38%                 | ~7500 steps                        |
| Fully Right       | 280         | 2048        | 4000          | X: Right 100%               | Y: Rest 0%                  | ~14640 steps (max goal)             |
| Fully Left        | 4095        | 2048        | 100           | X: Left 100%                | Y: Rest 0%                  | ~366 steps (min goal, clamped to 500) |
| Fully Up          | 2048        | 335         | 2000          | X: Rest 0%                  | Y: Up 100%                  | ~7500 steps                        |
| Fully Down        | 2048        | 3950        | 2000          | X: Rest 0%                  | Y: Down 100%                | ~7500 steps                        |

---

### Data Processing and Display

The `task_display.c` module retrieves these raw joystick ADC values using `getter_joystick_x()` and `getter_joystick_y()`. It then converts these raw readings into a more intuitive percentage-based displacement and directional indication (e.g., "X: Up 50%"). This processed information is dynamically updated and displayed on the SSD1306 OLED screen.

Additionally, when debug mode is enabled, both the raw and processed ADC values are transmitted via UART for external monitoring and debugging purposes, providing detailed insight into joystick performance.

The `adc_vr1` input, handled by `steps_handle_goal_setting` in `task_steps.c`, directly influences the `goalSteps` value. The raw `adc_vr1` range of 0–4095 is mapped to a `goalSteps` range of 500 to 15000, allowing the user to precisely set their step targets.

---

### IMU Module (`task_imu.c`) and Data Filtering

The `task_imu.c` module is responsible for interfacing with the Inertial Measurement Unit (IMU), specifically the LSM6DS sensor. This module directly reads raw accelerometer data, which are 16-bit signed integer values representing acceleration along the X, Y, and Z axes (`accel->x`, `accel->y`, `accel->z`). These are direct register readings from the IMU and should not be confused with the general-purpose ADC values obtained from the joystick.

#### Raw IMU Accelerometer Data Examples

| State           | accel->x (Raw) | accel->y (Raw) | accel->z (Raw) | Description                                                  |
|-----------------|----------------|----------------|----------------|--------------------------------------------------------------|
| At Rest (Flat)  | 0              | 0              | +16384         | Represents ~1g acceleration along the Z-axis (gravity), typical when stationary and flat. |
| Tilted Forward  | -8192          | 0              | +14194         | Shows a negative X acceleration component, indicating a tilt forward.  |
| Tilted Left     | 0              | +8192          | +14194         | Shows a positive Y acceleration component, indicating a tilt to the left. |
| During Movement/Step | +2000 to -2000 | +3000 to -3000 | +17000 to +15000 | Dynamic fluctuations during walking or sudden motion, indicating steps. |

---

### Data Filtering

Raw IMU data is inherently noisy due to sensor imperfections, vibrations, and environmental factors. To extract meaningful information, such as step counts, from these raw readings, data filtering is essential. Although the provided `task_imu.c` snippet focuses on raw data acquisition, the module's brief explicitly mentions "filtering" for processing data for step detection and movement tracking.

Typical filtering techniques applied to IMU data include:

- **Low-Pass Filtering:** Smooths out high-frequency noise to capture slower, significant movements, improving peak detection reliability.
- **Moving Average Filter:** Averages a set number of past data points to smooth current readings.
- **Thresholding and Peak Detection:** Identifies distinct peaks in the acceleration data that correlate with individual steps.
- **Activity Recognition Algorithms:** Combines accelerometer and gyroscope data and may use machine learning for differentiating activities and improving step counting accuracy.

While the specific filtering implementation is not detailed in the provided code snippet, these techniques are paramount for converting raw, noisy IMU readings into reliable step counts and movement insights.

---

### Scheduler Timing Diagram

| Task           | Frequency | Purpose               |
|----------------|-----------|-----------------------|
| Button         | 250 Hz    | Button poll task      |
| Joystick       | 250 Hz    | Joystick ADC read task|
| IMU            | 100 Hz    | Raw acceleration data |
| Buzzer Update  | 100 Hz    | Buzzer Control Task   |
| Display        | 10 Hz     | Display Update Task   |
| Blinky         | 4 Hz      | RGB LED blink task    |

The CPU usage was minimal under this time-based scheduler. Tasks did not block each other or hog the CPU, and all I/O was non-blocking or interrupt-driven.

--- 

## 4. Conclusion 

This project successfully demonstrated the design and implementation of a modular embedded system for a step counter project using the C language. By learning how to manipulate, development and test a program on the STM32C071 microcontroller and an RCAP board, the final code was able to meet most of the functional and visual requirements set out in the final demonstration, such as step detection, distance tracking and goal setting and user feedback. 

### What went well: 

- **Accurate Step Detection**: The algorithm worked reliably for walking for people of similar height with effective filtering to reduce noise. 

- **Responsive User Interface**: The display, joystick, and LEDs provided intuitive and real-time feedback, and there weren't any blatant latency insures or input delay, due to refresh rate and polling rate.  

### What Did not go well: 

Throughout the project, there were not really any major code issues or setup issues that completely altered how the project progressed, however there were some hiccups upon completion of the project. 
- **Test Mode Values and Real Values**: When using the test mode, and wanting to return to regular usage, the steps from the test mode did not translate over to the real-world data.  

- **Code Generation**: this project was mainly completed on a personal device, and the code generator wasn’t functioning as expected, and when trying to test and further progress using Lab computer, many build errors, warnings and issues would prevent further development. This was fixed by using lab computer to regenerate all necessary code and work from there, every week.  

### Things Learnt: 

* Programming on STM32 boards using C.
* Fundamentals of GPIO, ADC, PWM, scheduling and much more.
* Importance of modularity and filtering for real-time systems using real data.


### Future Improvements if more time allowed - Post Demonstration 

- **Step Detection**: Improve on the algorithm to detect steps for people of different heights and with different stride lengths. Testing on shorter people gives large differences compared to testing on tall people.  

- **UI Enhancements**: Use the built-in libraries to make the UI look nicer with different text and other elements to enhance the display  

Despite minor challenges, the step counter performed well for its intended use case. With additional time, further improvements could enhance its accuracy and usability.

--- 

**This README has had AI Assistance. AI has assisted writing, formatting and provided grammatical checking, all data provided has been manually collected and inputted** 