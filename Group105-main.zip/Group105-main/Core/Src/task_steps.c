/*
 * task_steps.c
 *
 *  Brief:     Manages step detection, step counting, and related goal tracking
 *             functionalities using accelerometer data and peak detection.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#include "task_steps.h"
#include "task_buzzer.h"
#include "app.h"
#include "stm32c0xx_hal.h"
#include <stdlib.h>
#include "task_display.h"
#include "pwm.h"
#include "buttons.h"
#include "rgb.h"
#include "globals.h"

bool goalReached = false;
bool settingGoal = false;

#define PWM_MAX 100
#define PWM_STEP 25

void steps_handle_goal_setting(uint16_t adc_vr1)
{
    static uint32_t joystickPressStartTime = 0;
    static bool pressTimingActive = false;
    static bool buttonPreviouslyPressed = false;
    static uint32_t previousGoalSteps = 1000;
    static bool longPressTriggered = false;
    static bool shortPressTriggered = false;
    static bool firstEnterGoalMode = true;

    distanceTravelled_x100 = (stepCount * 9) / 100;  // Update distance (cm x100)

    bool buttonPressed = (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == GPIO_PIN_SET);

    if (buttonPressed && !buttonPreviouslyPressed)
    {
        joystickPressStartTime = HAL_GetTick();
        pressTimingActive = true;
    }

    if (!buttonPressed && buttonPreviouslyPressed && pressTimingActive)
    {
        uint32_t pressDuration = HAL_GetTick() - joystickPressStartTime;

        if (pressDuration >= 1000)  // Long press toggles goal setting mode
        {
            settingGoal = !settingGoal;

            if (!settingGoal)
            {
                previousGoalSteps = goalSteps;
                goalReached = false;
            }

            currentScreen = SCREEN_GOAL;
            longPressTriggered = true;
        }
        else if (pressDuration >= 50 && pressDuration < 500 && settingGoal && !longPressTriggered)
        {
            // Short press cancels changes and exits goal setting
            goalSteps = previousGoalSteps;
            settingGoal = false;
            goalReached = false;
            firstEnterGoalMode = true;
            shortPressTriggered = true;
        }

        pressTimingActive = false;
        longPressTriggered = false;
    }

    buttonPreviouslyPressed = buttonPressed;

    if (!settingGoal) return;

    currentScreen = SCREEN_GOAL;

    if (firstEnterGoalMode)
    {
        previousGoalSteps = goalSteps;
        firstEnterGoalMode = false;
    }

    if (shortPressTriggered)
    {
        shortPressTriggered = false;
        return;
    }

    // Map VR1 ADC value to goal steps and adjust goal in increments of 50
    uint32_t vr1_mapped = (adc_vr1 * 15000) / 4095;
    int32_t goalAdjustment = ((int32_t)vr1_mapped - (int32_t)previousGoalSteps) / 50 * 50;
    int32_t newGoal = (int32_t)previousGoalSteps + goalAdjustment;

    // Clamp goalSteps within 500 to 15000
    if (newGoal > 15000)
        goalSteps = 15000;
    else if (newGoal < 500)
        goalSteps = 500;
    else
        goalSteps = (uint32_t)newGoal;

    goalReached = false;
}

void steps_handle_test_mode(uint16_t adc_x, uint16_t adc_y, uint32_t* testStepCount)
{
    const uint16_t ADC_MAX = 4095;
    const uint16_t CENTRE = ADC_MAX / 2;
    const uint16_t DEADZONE = 250;

    int32_t displacement = (int32_t)adc_y - CENTRE;
    currentScreen = SCREEN_TEST;

    if (abs(displacement) > DEADZONE)
    {
        int8_t direction = (displacement < 0) ? 1 : -1;

        // Cubic scaling for smoother speed control based on joystick displacement
        float percent = (float)abs(displacement - DEADZONE) / (ADC_MAX / 2 - DEADZONE);
        float scaled = percent * percent * percent;

        uint32_t maxRate = goalSteps / 10000;
        if (maxRate < 1) maxRate = 1;

        uint32_t speed = (uint32_t)(scaled * maxRate);
        if (speed == 0) speed = 1;

        int32_t proposed = (int32_t)(*testStepCount) + direction * speed;

        // Clamp testStepCount within 0 and goalSteps
        if (proposed > (int32_t)goalSteps)
            proposed = goalSteps;
        if (proposed < 0)
            proposed = 0;

        *testStepCount = (uint32_t)proposed;

        stepCount = *testStepCount;
        steps_check_goal_and_buzzer();
    }
}

void steps_check_goal_and_buzzer(void)
{
    // Trigger buzzer once on reaching goal
    if (stepCount >= goalSteps && !goalReached)
    {
        buzzer_start();
        goalReached = true;
    }

    if (stepCount < goalSteps && goalReached)
    {
        goalReached = false;
    }

    uint32_t progress = (stepCount * 100) / goalSteps;

    // Adjust PWM brightness for low progress and turn off some LEDs
    if (progress < 25)
    {
        uint32_t brightness = (PWM_MAX * progress) / 25;
        pwm_setDutyCycle(&htim2, TIM_CHANNEL_3, brightness);

        rgb_led_off(RGB_RIGHT);
        rgb_led_off(RGB_DOWN);
        rgb_led_off(RGB_LEFT);
    }
    else
    {
        pwm_setDutyCycle(&htim2, TIM_CHANNEL_3, PWM_MAX);
    }

    // Turn on RGB LEDs progressively based on step progress
    rgb_led_on(RGB_UP);

    if (progress >= 50)
        rgb_led_on(RGB_RIGHT);
    else
        rgb_led_off(RGB_RIGHT);

    if (progress >= 75)
        rgb_led_on(RGB_DOWN);
    else
        rgb_led_off(RGB_DOWN);

    if (progress >= 100)
        rgb_led_on(RGB_LEFT);
    else
        rgb_led_off(RGB_LEFT);
}
