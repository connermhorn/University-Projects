/*
 * peak.c
 *
 * Description:
 *   Processes accelerometer magnitude data to detect peaks for step counting.
 *   Used in conjunction with filtering logic and activity tracking.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#include "peak.h"
#include "stm32c0xx_hal.h"

#define THRESHOLD 6000000
#define GRAVITY 16384
#define STEP_DEBOUNCE_MS 450  // Minimum time between steps in milliseconds

static int steps = 0;
static int above = 0;
static uint32_t lastStepTime = 0;

void peak_detector_init(void) {
    steps = 0;
    above = 0;
    lastStepTime = 0;
}

void peak_detector_update(accel_t *accel) {
    int32_t x = (int32_t)accel->x;
    int32_t y = (int32_t)accel->y;
    int32_t z = (int32_t)accel->z;

    // Calculate total magnitude squared
    int32_t mag2 = x * x + y * y + z * z;

    // Subtract expected gravity squared to find net motion energy
    int32_t delta = mag2 - (GRAVITY * GRAVITY);
    if (delta < 0) delta = -delta;

    uint32_t now = HAL_GetTick();

    // Peak detection with debounce
    if (delta > THRESHOLD && !above) {
        if (now - lastStepTime >= STEP_DEBOUNCE_MS) {
            steps++;
            lastStepTime = now;
        }
        above = 1;
    } else if (delta <= THRESHOLD) {
        above = 0;
    }
}

int get_step_count(void) {
    return steps;
}
