/*
 * globals.c
 *
 * Description:
 *   Stores global variables shared across modules for application state, mode flags, and metrics.
 *   Helps centralize cross-module state management.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#include "globals.h"
#include "task_display.h"

uint32_t stepCount = 0;
uint32_t goalSteps = 1000;
uint32_t distanceTravelled_x100 = 0;
DisplayScreen_t currentScreen = SCREEN_STEPS;
bool SwitchUnits = false;
bool test_mode = false;
