/*
 * task_button.c
 *
 * Description:
 *   Handles button input logic including:
 *     - SW1 (UP): Manual step increment.
 *     - SW2 (DOWN): Toggles debug mode and detects double-tap to toggle Test Mode.
 *   Integrates with step counting, display mode, and application state.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#include "task_button.h"
#include "buttons.h"
#include "rgb.h"
#include "pwm.h"
#include "tim.h"
#include "task_display.h"
#include "app.h"
#include "task_steps.h"

#define PWM_MAX 100   // Assuming full brightness is 100000 pulses
#define PWM_STEP 25   // Increase in steps of 10000 pulses
#define LED_CHANNEL TIM_CHANNEL_3 // Update with the correct timer channel

extern TIM_HandleTypeDef htim2;  // Update with the correct timer handle
extern bool settingGoal;

void button_task_execute(void)
{
    static uint32_t lastDownPressTime = 0;
    static uint8_t tapCount = 0;

    buttons_update();

    if (settingGoal || test_mode)
    {
    	if (buttons_checkButton(UP) == PUSHED)
    	{
    		//Button press not detected
    	}
    }

    if (buttons_checkButton(UP) == PUSHED)
    {
        // Increment step counter by 80 steps per press
        stepCount += 80;
        steps_check_goal_and_buzzer(); //check goal status when sw1 is pushed
    }

    // DOWN button functionality (SW2)
    if (buttons_checkButton(DOWN) == PUSHED)
    {
        //rgb_led_toggle(RGB_DOWN); <- Remove comment for LED functionality/debug purposes

        debug_mode = !debug_mode;

        uint32_t now = HAL_GetTick();

        if (now - lastDownPressTime < 400)
        {
            tapCount++;
            if (tapCount == 2)
            {
                test_mode = !test_mode;
                if (test_mode)
                {
                    currentScreen = SCREEN_TEST;
                }
                else
                {
                    currentScreen = SCREEN_STEPS;
                }
                tapCount = 0;
            }
        }
        else
        {
            tapCount = 1;
        }
        lastDownPressTime = now;  // Update last down press time
    }


}
