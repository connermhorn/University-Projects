/*
 * task_blinky.c
 *
 *  Brief:     Implements the blinking task for the RGB LEDs.
 *             Handles periodic toggling of LED states to provide visual feedback.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#include "gpio.h"
#include "task_blinky.h"

void blinky_task_execute(void)
{
    // Toggle all RGB LEDs (or specific LEDs as needed)
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
}
