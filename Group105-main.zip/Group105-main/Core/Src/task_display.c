/*
 * task_display.c / task_display.h
 *
 * Description:
 *   Manages SSD1306 OLED display rendering.
 *   Responsible for updating screens based on current application state and mode.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#include "task_display.h"
#include "adc.h"
#include "ssd1306_conf.h"
#include "ssd1306_fonts.h"
#include "ssd1306.h"
#include "i2c.h"
#include "task_joystick.h"
#include "stdio.h"
#include "usart.h"
#include <string.h>
#include "buttons.h"
#include <stdlib.h>
#include "app.h"
#include "globals.h"

bool debug_mode = false;
bool uart_debug_enabled = true;

void display_init()
{
	ssd1306_Init();
}

void display_update()
{
    char buffer[20]; // Buffer for formatted ADC values

    static uint8_t initialized = 0;
    if (!initialized)
    {
        ssd1306_SetCursor(0, 0);
        ssd1306_WriteString("J-S Position:", Font_7x10, White);
        ssd1306_UpdateScreen();
        initialized = 1;
    }

    // Fetch ADC values
    uint16_t adc_x = getter_joystick_x();
    uint16_t adc_y = getter_joystick_y();

    const uint16_t ADC_MAX = 4095;
    const uint16_t CENTRE = ADC_MAX / 2;
    const uint16_t CENTRE_THRESHOLD = 250; // Dead zone threshold

    // Calibrated observed values
    const uint16_t X_MIN = 280;   // Joystick fully up
    const uint16_t X_MAX = 4095;  // Joystick fully down
    const uint16_t Y_MIN = 335;   // Joystick fully right
    const uint16_t Y_MAX = 3950;  // Joystick fully left

    int16_t x_disp = 0;
    int16_t y_disp = 0;

    const char* x_dir = "Rest";
    const char* y_dir = "Rest";

    // X direction (Up/Down)
    if (adc_x < (CENTRE - CENTRE_THRESHOLD))
    {
        x_dir = "Up";
        x_disp = ((CENTRE - adc_x) * 100) / (CENTRE - X_MIN);
        if (x_disp > 100) x_disp = 100;
    }
    else if (adc_x > (CENTRE + CENTRE_THRESHOLD))
    {
        x_dir = "Left";
        x_disp = ((adc_x - CENTRE) * 100) / (X_MAX - CENTRE);
        if (x_disp > 100) x_disp = 100;
    }

    // Y direction (Right/Left)
    if (adc_y < (CENTRE - CENTRE_THRESHOLD))
    {
        y_dir = "Down";
        y_disp = ((CENTRE - adc_y) * 100) / (CENTRE - Y_MIN);
        if (y_disp > 100) y_disp = 100;
    }
    else if (adc_y > (CENTRE + CENTRE_THRESHOLD))
    {
        y_dir = "Right";
        y_disp = ((adc_y - CENTRE) * 100) / (Y_MAX - CENTRE);
        if (y_disp > 100) y_disp = 100;
    }

    // Display X direction & displacement
    ssd1306_SetCursor(0, 15);
    snprintf(buffer, sizeof(buffer), "X: %s %3d%%   ", x_dir, x_disp);
    ssd1306_WriteString(buffer, Font_7x10, White);

    // Display Y direction & displacement
    ssd1306_SetCursor(0, 30);
    snprintf(buffer, sizeof(buffer), "Y: %s %3d%%   ", y_dir, y_disp);
    ssd1306_WriteString(buffer, Font_7x10, White);

    // UART output - if toggled on
    if (uart_debug_enabled)
    {
		char uart_msg[50];
		snprintf(uart_msg, sizeof(uart_msg), "X: %s %3d%%, Y: %s %3d%%\r\n", x_dir, x_disp, y_dir, y_disp);
		HAL_UART_Transmit(&huart2, (uint8_t*)uart_msg, strlen(uart_msg), HAL_MAX_DELAY);
    }

    ssd1306_UpdateScreen();
}


void display_raw_adc()
{
    char buffer[20];

    uint16_t adc_x = getter_joystick_x();
    uint16_t adc_y = getter_joystick_y();

    // Clear the screen before displaying raw ADC values
	ssd1306_Fill(Black); // Clear the screen
	ssd1306_SetCursor(0, 0); // Reset cursor to top
	ssd1306_WriteString("J-S Position:", Font_7x10, White);

    ssd1306_SetCursor(0, 15);
    snprintf(buffer, sizeof(buffer), "X: %u", adc_x);
    ssd1306_WriteString(buffer, Font_7x10, White);

    ssd1306_SetCursor(0, 30);
    snprintf(buffer, sizeof(buffer), "Y: %u", adc_y);
    ssd1306_WriteString(buffer, Font_7x10, White);

    // Send raw ADC values to serial output (UART)
    if (uart_debug_enabled)
    {
		char uart_msg[50];
		snprintf(uart_msg, sizeof(uart_msg), "X: %u, Y: %u\r\n", adc_x, adc_y);
		HAL_UART_Transmit(&huart2, (uint8_t*)uart_msg, strlen(uart_msg), HAL_MAX_DELAY);
    }

    ssd1306_UpdateScreen();
}


void display_task_execute(void)
{
	// Check if SW2 is pressed to toggle debug mode
	if (buttons_checkButton(DOWN) == PUSHED)
	{
		debug_mode = !debug_mode;  // Toggle debug mode
		uart_debug_enabled = debug_mode;  // UART debug toggle
	}


	char buffer[32];
	ssd1306_Fill(Black);

	switch (currentScreen)
	{
		case SCREEN_STEPS:
			ssd1306_SetCursor(0, 0);
			ssd1306_WriteString("Current Steps:", Font_7x10, White);
			if (SwitchUnits)
			{
				uint8_t pct = (stepCount * 100) / goalSteps;
				snprintf(buffer, sizeof(buffer), "%3d%%", pct);
			}
			else
			{
				snprintf(buffer, sizeof(buffer), "%lu steps", stepCount);
			}
			ssd1306_SetCursor(0, 15);
			ssd1306_WriteString(buffer, Font_7x10, White);
			break;

		case SCREEN_DISTANCE:
			ssd1306_SetCursor(0, 0);
			ssd1306_WriteString("Distance:", Font_7x10, White);
			if (SwitchUnits)
			{
				uint32_t yards_x10 = (distanceTravelled_x100 * 10936) / 100; // Convert scaled km to scaled yards (x10 for 1 decimal)
				snprintf(buffer, sizeof(buffer), "%lu.%01lu yd", yards_x10 / 10, yards_x10 % 10);
			}
			else
			{
				snprintf(buffer, sizeof(buffer), "%lu.%02lu km", distanceTravelled_x100 / 100, distanceTravelled_x100 % 100);
			}
			ssd1306_SetCursor(0, 15);
			ssd1306_WriteString(buffer, Font_7x10, White);
			break;

		case SCREEN_GOAL:
			ssd1306_SetCursor(0, 0);
			ssd1306_WriteString("Goal Progress:", Font_7x10, White);
			snprintf(buffer, sizeof(buffer), "%lu / %lu", stepCount, goalSteps);
			ssd1306_SetCursor(0, 15);
			ssd1306_WriteString(buffer, Font_7x10, White);
			break;

		case SCREEN_TEST:
		    ssd1306_SetCursor(0, 0);
		    ssd1306_WriteString("TEST MODE:", Font_7x10, White);
		    		    ssd1306_SetCursor(0, 15);
		    snprintf(buffer, sizeof(buffer), "Steps: %lu", stepCount);
		    ssd1306_WriteString(buffer, Font_7x10, White);
		    ssd1306_UpdateScreen();
		    break;
	}
	ssd1306_UpdateScreen();
}



