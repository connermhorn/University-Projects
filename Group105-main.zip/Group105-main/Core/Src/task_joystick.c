/*
 * task_joystick.c
 *
 *  Brief:     Handles joystick ADC reading, filtering, and processing
 *             to provide position data for user input and interface control.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */


#include "task_joystick.h"
#include "adc.h"
#include "buttons.h"
#include "app.h"
#include "task_steps.h"
#include "globals.h"

#define ADC_MAX 4095
#define CENTRE (ADC_MAX / 2)
#define CENTRE_THRESHOLD 300

static uint16_t raw_adc[3];
static bool prevTestMode = false;
uint32_t testStepCount = 0;

void joystick_task_execute(void)
{
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)raw_adc, 3);
    uint16_t adc_vr1 = raw_adc[0];
    uint16_t adc_y = raw_adc[1];
    uint16_t adc_x = raw_adc[2];

    if (test_mode && !prevTestMode)
    {
        testStepCount = stepCount;
    }
    else if (!test_mode && prevTestMode)
    {
        stepCount = testStepCount;
        steps_check_goal_and_buzzer();
    }

    prevTestMode = test_mode;

    if (test_mode)
    {
        steps_handle_test_mode(adc_x, adc_y, &testStepCount);
        stepCount = testStepCount;  // <- Add this line to update stepCount live
        return;
    }

    steps_handle_goal_setting(adc_vr1);

    // ----- Navigation and Unit Toggle -----
    static uint8_t lastLeftState = 0, lastRightState = 0, lastUpState = 0;

    if (adc_x > (CENTRE + CENTRE_THRESHOLD))  // LEFT
    {
        if (!lastLeftState)
        {
            currentScreen = (currentScreen + 1) % 3;
            lastLeftState = 1;
        }
    }
    else lastLeftState = 0;

    if (adc_x < (CENTRE - CENTRE_THRESHOLD))  // RIGHT
    {
        if (!lastRightState)
        {
            currentScreen = (currentScreen == 0) ? 2 : currentScreen - 1;
            lastRightState = 1;
        }
    }
    else lastRightState = 0;

    if (adc_y < (CENTRE - CENTRE_THRESHOLD))  // UP = toggle units
    {
        if (!lastUpState)
        {
            SwitchUnits = !SwitchUnits;
            lastUpState = 1;
        }
    }
    else lastUpState = 0;
}

uint16_t getter_joystick_x(void)
{
    return raw_adc[2];
}

uint16_t getter_joystick_y(void)
{
    return raw_adc[1];
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    // Optional: handle ADC complete event here
}
