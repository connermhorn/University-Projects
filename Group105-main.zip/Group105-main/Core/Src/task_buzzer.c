/*
 * task_buzzer.c
 *
 * Description:
 *   Controls piezo buzzer output for audio feedback using pre-defined tunes.
 *   Triggered upon reaching goal or specific app events.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#include "stdio.h"
#include "task_buzzer.h"
#include "app.h"
#include "task_joystick.h"
#include "task_display.h"
#include "pwm.h"
#include "tim.h"
#include "stdbool.h"
#include "stdint.h"

typedef struct {
    uint32_t freq;     // Frequency in Hz
    uint32_t duration; // Duration in ms
} Note_t;

// Define any tune (frequency, duration)
static const Note_t nokiaTune[] = {
    { 659, 400 }
};

#define TUNE_LENGTH (sizeof(nokiaTune)/sizeof(Note_t))

static bool buzzerActive = false;
static uint32_t buzzerNoteIndex = 0;
static uint32_t buzzerNoteStartTime = 0;

void buzzer_start(void)
{
    buzzerActive = true;
    buzzerNoteIndex = 0;
    buzzerNoteStartTime = HAL_GetTick();
    buzzer_play_note(nokiaTune[buzzerNoteIndex].freq);
}

void buzzer_play_note(uint32_t frequency)
{
    if (frequency == 0)
    {
        __HAL_TIM_SET_COMPARE(&htim16, TIM_CHANNEL_1, 0);  // Silence
    }
    else
    {
        uint32_t period = 1000000 / frequency;
        htim16.Init.Period = period;
        HAL_TIM_PWM_Init(&htim16);
        __HAL_TIM_SET_AUTORELOAD(&htim16, period);
        __HAL_TIM_SET_COMPARE(&htim16, TIM_CHANNEL_1, period / 2);
        HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
    }
}

void buzzer_task_execute(void)
{
    if (!buzzerActive) return;

    uint32_t now = HAL_GetTick();
    if (now - buzzerNoteStartTime >= nokiaTune[buzzerNoteIndex].duration)
    {
        buzzerNoteIndex++;

        if (buzzerNoteIndex >= TUNE_LENGTH)
        {
            // End of tune
            HAL_TIM_PWM_Stop(&htim16, TIM_CHANNEL_1);
            buzzerActive = false;
        }
        else
        {
            buzzer_play_note(nokiaTune[buzzerNoteIndex].freq);
            buzzerNoteStartTime = now;
        }
    }
}
