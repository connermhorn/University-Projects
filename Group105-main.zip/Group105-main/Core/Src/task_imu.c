/*
 * task_imu.c
 *
 *  Brief:     Implements IMU (Inertia Measurement Unit) related tasks,
 *             including accelerometer initialization, reading, filtering,
 *             and processing data for step detection and movement tracking.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#include "task_imu.h"
#include "imu_lsm6ds.h"  // Provided driver

void imu_init(void) {
    // CTRL1_XL = 0x10, value = 0x60 = 416Hz, 2g, high-performance
    imu_lsm6ds_write_byte(0x10, 0x60);
}

void imu_read_accel(accel_t *accel) {
    uint8_t xl = imu_lsm6ds_read_byte(0x28);
    uint8_t xh = imu_lsm6ds_read_byte(0x29);
    uint8_t yl = imu_lsm6ds_read_byte(0x2A);
    uint8_t yh = imu_lsm6ds_read_byte(0x2B);
    uint8_t zl = imu_lsm6ds_read_byte(0x2C);
    uint8_t zh = imu_lsm6ds_read_byte(0x2D);

    accel->x = (int16_t)((xh << 8) | xl);
    accel->y = (int16_t)((yh << 8) | yl);
    accel->z = (int16_t)((zh << 8) | zl);
}
