/*
 * filters.c
 *
 *  Brief:     Implements digital filtering functions for sensor data smoothing.
 *             Provides initialization and update routines for low-pass filters
 *             used to reduce noise in accelerometer and other analog signals.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#include "filter.h"

void filter_init(filter_t *filt) {
    for (int i = 0; i < FILTER_SIZE; i++) {
        filt->buffer[i] = 0;
    }
    filt->index = 0;
}

int16_t filter_update(filter_t *filt, int16_t input) {
    filt->buffer[filt->index] = input;
    filt->index = (filt->index + 1) % FILTER_SIZE;

    int32_t sum = 0;
    for (int i = 0; i < FILTER_SIZE; i++) {
        sum += filt->buffer[i];
    }

    return (int16_t)(sum / FILTER_SIZE);
}


