/*
 * app.c
 *
 *  Brief:     Main application file for Step Counter project.
 *             Initializes peripherals and runs scheduled tasks:
 *             - RGB LED blinking
 *             - Button polling
 *             - Joystick reading
 *             - Display updating
 *             - Buzzer control
 *             - Accelerometer and step detection
 *
 *  Date: 		23/05/2025
 *  Authors:	chi117 and cho183
 */

#include "app.h"
#include "main.h"
#include "gpio.h"
#include "buttons.h"
#include "rgb.h"
#include "adc.h"
#include "task_blinky.h"
#include "task_display.h"
#include "task_button.h"
#include "task_joystick.h"
#include "i2c.h"
#include "usart.h"
#include "tim.h"
#include "pwm.h"
#include "task_buzzer.h"
#include "task_imu.h"
#include "task_steps.h"
#include "filter.h"
#include "peak.h"
#include "globals.h"


/* Scheduler tick frequency (Hz) */
#define TICK_FREQUENCY_HZ 1000

/* Converts frequency to scheduler ticks */
#define HZ_TO_TICKS(FREQUENCY_HZ) (TICK_FREQUENCY_HZ / (FREQUENCY_HZ))

/* Task frequencies */
#define BLINKY_TASK_FREQUENCY_HZ     4     // 4 Hz
#define BUTTON_TASK_FREQUENCY_HZ     250   // 250 Hz
#define JOYSTICK_TASK_FREQUENCY_HZ   250   // 250 Hz
#define DISPLAY_TASK_FREQUENCY_HZ    10    // 10 Hz
#define BUZZER_TASK_FREQUENCY_HZ     100   // 100 Hz
#define IMU_TASK_FREQUENCY_HZ        100   // 100 Hz

/* Task periods in scheduler ticks */
#define BLINKY_TASK_PERIOD_TICKS     HZ_TO_TICKS(BLINKY_TASK_FREQUENCY_HZ)
#define BUTTON_TASK_PERIOD_TICKS     HZ_TO_TICKS(BUTTON_TASK_FREQUENCY_HZ)
#define JOYSTICK_TASK_PERIOD_TICKS   HZ_TO_TICKS(JOYSTICK_TASK_FREQUENCY_HZ)
#define DISPLAY_TASK_PERIOD_TICKS    HZ_TO_TICKS(DISPLAY_TASK_FREQUENCY_HZ)
#define BUZZER_TASK_PERIOD_TICKS     HZ_TO_TICKS(BUZZER_TASK_FREQUENCY_HZ)
#define IMU_TASK_PERIOD_TICKS        HZ_TO_TICKS(IMU_TASK_FREQUENCY_HZ)


/* Next scheduled run times for tasks */
static uint32_t blinkyTaskNextRun = 0;
static uint32_t buttonTaskNextRun = 0;
static uint32_t joystickTaskNextRun = 0;
static uint32_t displayTaskNextRun = 0;
static uint32_t buzzerTaskNextRun = 0;
static uint32_t imuTaskNextRun = 0;

/* Filters for accelerometer axes */
static filter_t fx, fy, fz;


/* Forward declarations for task functions */
void task_blinky(void);   // RGB LED blink task
void task_button(void);   // Button poll task
void task_joystick(void); // Joystick ADC read task
void task_display(void);  // Display update task
void task_buzzer(void);   // Buzzer control task


void app_main(void)
{
    /* Initialize globals */
    stepCount = 0;
    distanceTravelled_x100 = 0.0f;
    goalSteps = 1000;

    /* Start buzzer */
    buzzer_start();

    /* Initialize peripherals */
    rgb_colour_all_on();
    buttons_init();
    MX_I2C1_Init();
    display_init();
    display_update();

    /* Initialize PWM timers */
    MX_TIM2_Init();
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
    pwm_setDutyCycle(&htim2, TIM_CHANNEL_3, 0);

    MX_TIM16_Init();
    HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
    pwm_setDutyCycle(&htim16, TIM_CHANNEL_1, 0);

    /* Initialize IMU and filters */
    imu_init();
    filter_init(&fx);
    filter_init(&fy);
    filter_init(&fz);
    peak_detector_init();

    /* Initialize scheduler timers */
    blinkyTaskNextRun = HAL_GetTick() + BLINKY_TASK_PERIOD_TICKS;
    buttonTaskNextRun = HAL_GetTick() + BUTTON_TASK_PERIOD_TICKS;
    joystickTaskNextRun = HAL_GetTick() + JOYSTICK_TASK_PERIOD_TICKS;
    displayTaskNextRun = HAL_GetTick() + DISPLAY_TASK_PERIOD_TICKS;
    buzzerTaskNextRun = HAL_GetTick() + BUZZER_TASK_PERIOD_TICKS;
    imuTaskNextRun = HAL_GetTick() + IMU_TASK_PERIOD_TICKS;

    /* Main loop */
    while (1)
    {
        uint32_t ticks = HAL_GetTick();

        if (ticks >= blinkyTaskNextRun)
        {
            blinky_task_execute();
            blinkyTaskNextRun += BLINKY_TASK_PERIOD_TICKS;
        }

        if (ticks >= buttonTaskNextRun)
        {
            button_task_execute();
            buttonTaskNextRun += BUTTON_TASK_PERIOD_TICKS;
        }

        if (ticks >= joystickTaskNextRun)
        {
            joystick_task_execute();
            joystickTaskNextRun += JOYSTICK_TASK_PERIOD_TICKS;
        }

        if (ticks >= displayTaskNextRun)
        {
            display_task_execute();
            displayTaskNextRun += DISPLAY_TASK_PERIOD_TICKS;
        }

        if (ticks >= buzzerTaskNextRun)
        {
            buzzer_task_execute();
            buzzerTaskNextRun += BUZZER_TASK_PERIOD_TICKS;
        }

        if (ticks >= imuTaskNextRun)
        {
            accel_t raw, filtered;

            imu_read_accel(&raw);

            filtered.x = filter_update(&fx, raw.x);
            filtered.y = filter_update(&fy, raw.y);
            filtered.z = filter_update(&fz, raw.z);

            peak_detector_update(&filtered);

            if (!test_mode)
            {
                stepCount = get_step_count();
                steps_check_goal_and_buzzer();
            }

            imuTaskNextRun += IMU_TASK_PERIOD_TICKS;
        }
    }
}



