/*
 * task_button.h
 *
 * Description:
 *   Handles button input logic including:
 *     - SW1 (UP): Manual step increment.
 *     - SW2 (DOWN): Toggles debug mode and detects double-tap to toggle Test Mode.
 *   Integrates with step counting, display mode, and application state.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#ifndef INC_TASK_BUTTON_H_
#define INC_TASK_BUTTON_H_

void button_task_execute(void);


#endif /* INC_TASK_BUTTON_H_ */
