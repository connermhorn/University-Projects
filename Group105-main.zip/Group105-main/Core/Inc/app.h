/*
 * app.h
 *
 *  Created on: Feb 27, 2025
 *      Author: chi117
 */

#ifndef INC_APP_H_
#define INC_APP_H_

#include <stdint.h>
#include <stdbool.h>

// Main entry point
void app_main(void);

// Display screen state enum
typedef enum {
    SCREEN_STEPS,
    SCREEN_DISTANCE,
    SCREEN_GOAL,
	SCREEN_TEST
} DisplayScreen_t;

// Global screen state (declared in app.c, used elsewhere)
extern DisplayScreen_t currentScreen;

// Step counter app-wide variables
extern uint32_t stepCount;
extern float distanceTravelled;
extern uint32_t goalSteps;
extern bool test_mode;
extern bool SwitchUnits;
extern bool goalSettingMode;


#endif /* INC_APP_H_ */
