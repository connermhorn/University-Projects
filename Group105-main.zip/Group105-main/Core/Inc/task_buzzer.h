/*
 * task_buzzer.h
 *
 * Description:
 *   Controls piezo buzzer output for audio feedback using pre-defined tunes.
 *   Triggered upon reaching goal or specific app events.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#ifndef INC_TASK_BUZZER_H_
#define INC_TASK_BUZZER_H_

#include "stdint.h"

void buzzer_start(void);
void buzzer_play_note(uint32_t frequency);
void buzzer_task_execute(void);


#endif /* INC_TASK_BUZZER_H_ */
