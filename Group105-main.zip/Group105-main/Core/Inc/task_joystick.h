/*
 * task_joystick.h
 *
 *  Brief:     Handles joystick ADC reading, filtering, and processing
 *             to provide position data for user input and interface control.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#ifndef INC_TASK_JOYSTICK_H_
#define INC_TASK_JOYSTICK_H_

#include <stdint.h>

void joystick_task_execute(void);
uint16_t getter_joystick_x(void);
uint16_t getter_joystick_y(void);

#endif /* INC_TASK_JOYSTICK_H_ */
