/*
 * peak.c
 *
 * Description:
 *   Processes accelerometer magnitude data to detect peaks for step counting.
 *   Used in conjunction with filtering logic and activity tracking.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#ifndef PEAK_H
#define PEAK_H

#include "task_imu.h"

void peak_detector_init(void);
void peak_detector_update(accel_t *accel);
int get_step_count(void);

#endif
