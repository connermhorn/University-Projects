/*
 * task_blinky.h
 *
 *  Brief:     Implements the blinking task for the RGB LEDs.
 *             Handles periodic toggling of LED states to provide visual feedback.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#ifndef TASK_BLINKY_H_
#define TASK_BLINKY_H_

void blinky_task_execute(void);

#endif



