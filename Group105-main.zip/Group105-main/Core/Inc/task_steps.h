/*
 * task_steps.h
 *
 *  Brief:     Manages step detection, step counting, and related goal tracking
 *             functionalities using accelerometer data and peak detection.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */


#ifndef TASK_STEPS_H
#define TASK_STEPS_H

#include <stdint.h>
#include <stdbool.h>


void steps_handle_goal_setting(uint16_t adc_vr1);
void steps_handle_test_mode(uint16_t adc_x, uint16_t adc_y, uint32_t* testStepCount);


void steps_check_goal_and_buzzer(void);

/**
 * @brief Flag to track if the step goal has been reached.
 */
extern bool goalReached;

#endif // TASK_STEPS_H
