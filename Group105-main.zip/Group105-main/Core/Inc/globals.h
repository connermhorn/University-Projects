/**
 * globals.h
 *
 * Global shared variables across tasks and modules.
 *
 * Authors: cho183, chi117
 * Date: 23/05/2025
 */

#ifndef GLOBALS_H
#define GLOBALS_H

#include <stdint.h>
#include <stdbool.h>
#include "app.h"

extern uint32_t stepCount;
extern uint32_t goalSteps;
extern uint32_t distanceTravelled_x100;
extern DisplayScreen_t currentScreen;
extern bool SwitchUnits;
extern bool test_mode;

#endif // GLOBALS_H
