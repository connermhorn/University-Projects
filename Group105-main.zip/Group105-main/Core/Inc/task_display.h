/*
 * task_display.c / task_display.h
 *
 * Description:
 *   Manages SSD1306 OLED display rendering.
 *   Responsible for updating screens based on current application state and mode.
 *
 *  Created on: 23/05/2025
 *      Author: cho183, chi117
 */

#ifndef INC_TASK_DISPLAY_H_
#define INC_TASK_DISPLAY_H_

#include <stdint.h>
#include <stdbool.h>
#include "ssd1306.h"

void display_init(void);
void display_update(void);  // Existing function (processed joystick data)
void display_raw_adc(void); // New function for raw ADC values
void display_task_execute(void); // Executes display task logic

extern bool debug_mode;  // Declare debug_mode for use in other files

#endif /* INC_TASK_DISPLAY_H_ */
