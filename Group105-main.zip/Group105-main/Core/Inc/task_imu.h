/*
 * task_imu.h
 *
 *  Brief:     Implements IMU (Inertia Measurement Unit) related tasks,
 *             including accelerometer initialization, reading, filtering,
 *             and processing data for step detection and movement tracking.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */

#ifndef TASK_IMU_H
#define TASK_IMU_H

#include <stdint.h>

typedef struct {
    int16_t x;
    int16_t y;
    int16_t z;
} accel_t;

void imu_init(void);
void imu_read_accel(accel_t *accel);

#endif
