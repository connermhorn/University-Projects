/*
 * filters.h
 *
 *  Brief:     Implements digital filtering functions for sensor data smoothing.
 *             Provides initialization and update routines for low-pass filters
 *             used to reduce noise in accelerometer and other analog signals.
 *
 *  Created on: 23/05/2025
 *  Authors:   chi117 and cho183
 */


#ifndef FILTER_H
#define FILTER_H

#include <stdint.h>

#define FILTER_SIZE 10

typedef struct {
    int16_t buffer[FILTER_SIZE];
    int index;
} filter_t;

void filter_init(filter_t *filt);
int16_t filter_update(filter_t *filt, int16_t input);

#endif
